import requests
import json
from bs4 import BeautifulSoup
import warnings
import os
from pathlib import Path
warnings.filterwarnings("ignore")

def main():
	topic_name = input("Enter Topic Name: ")
	for page_no in range(1,10):
		url = "https://www.examveda.com/arithmetic-ability/practice-mcq-question-on-problems-on-trains/?page={}".format(page_no)
		get_questions(url,page_no,topic_name)



def get_questions(url,page_no,topic_name):
	r = requests.get(url=url)
	data = r.content
	html = BeautifulSoup(data, 'html')
	question  = html.find_all("div", {"class": "question-main"})
	# options  = html.find_all("div", {"class": "question-options"})
	options  = html.find_all("label")
	correct_option  = html.find_all("input", {"type": "hidden"})
	option_count=0
	# for i in range(1,len(correct_option)):
		# print(correct_option[i].get('value'))
	qNa_list = []
	for i in range(0,len(question)):
		try:
			question_str = question[i].text.strip()
		except:
			question_str = question
		try:
			correct_option_str = int(correct_option[i].get('value'))
		except:
			correct_option_str = int(correct_option)
		if(correct_option_str==1):
			correct_option_str = 'opt1'
		elif(correct_option_str==2):
			correct_option_str = 'opt2'
		elif(correct_option_str==3):
			correct_option_str = 'opt3'
		else:
			correct_option_str = 'opt4'		
		# input(correct_option)
		options_list = []
		for j in range(option_count,len(options)):
			option_count=option_count+1
			if(j%2==1):
				options_list.append(options[j].text)
				# input(option_string)
				if(option_count%8==0):
					# qNa_str = "{question:\"{}\",opt1:\"{}\",opt2:\"{}\",opt3:\"{}\",opt4:\"{}\",correct_opt:\"{}\"}".format(question_str,option_string,option_string,option_string,option_string,correct_option_str)
					qNa_str = {'question':question_str,'opt1':options_list[0],'opt2':options_list[1],'opt3':options_list[2],'opt4':options_list[3],'correct_opt':correct_option_str}
					qNa_list.append(qNa_str)
					break
	generate_html_quiz_page(json.dumps(qNa_list),page_no,topic_name)


def generate_html_quiz_page(qNa_list,page_no,topic_name):
	foldername = topic_name
	base_html = '''<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Time To Top</title>
    <meta
      name="viewport"
      content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css"
    />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://ml-tweety.github.io/style.css" />
    <script type="text/javascript">
        
      document.write(
        "<scr" +
          'ipt src="https://ml-tweety.github.io/components.js?' +
          Math.random() +
          '" type="text/javascript"></scr' +
          "ipt>"
      );
    </script>
    <script type="text/javascript">
      document.write(
        "<scr" +
          'ipt src="https://ml-tweety.github.io/pagination/categories/subjects/'''+topic_name+'''.js?' +
          Math.random() +
          '" type="text/javascript"></scr' +
          "ipt>"
      );
    </script>
  </head>
  <body>
    <i class="fas fa-arrow-up" onclick="topFunction()" id="backtotop"></i>
    <script>
      const mcq_data = '''+str(qNa_list)+''';
      which_ad = ads_midquestion_position();
    </script>
    <!-- Navbar Starts-->
    <script>
      navbar();
    </script>
    <!-- Navbar Ends -->
    <div class="container-fluid mt-2">
      <div class="row">
        <div
          class="col-sm-12 col-md-1 col-lg-1 col-xl-1 section-1 d-none d-lg-none d-xl-block"
        >
          <script>
            section_1();
          </script>
        </div>

        <div
          class="col-sm-12 col-md-8 col-lg-8 col-xl-8 section-2 section-seperator"
        >
          <!-- breadcrumb starts -->
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item">
                <a href="javascript:baseurl();">Home</a>
              </li>
              <li class="breadcrumb-item"><a href="#">Categories</a></li>
              <li class="breadcrumb-item"><a href="#">Computer</a></li>
              <li class="breadcrumb-item" aria-current="page">HTML</li>
            </ol>
          </nav>
          <!-- breadcrumb ends -->
          <table class="table">
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th class="card" id="question1">
                Q.1
                <script>
                  document.getElementById("question1").innerHTML +=
                    mcq_data[0]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered  shadow-lg">
                  <tr>
                    <td id="q1o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q1o1").innerHTML +=
                          mcq_data[0]["opt1"];
                        document
                          .getElementById("q1o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[0]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr class="card shadow-lg">
                    <td id="q1o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q1o2").innerHTML +=
                          mcq_data[0]["opt2"];
                        document
                          .getElementById("q1o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[0]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q1o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q1o3").innerHTML +=
                          mcq_data[0]["opt3"];
                        document
                          .getElementById("q1o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[0]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q1o4"class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q1o4").innerHTML +=
                          mcq_data[0]["opt4"];
                        document
                          .getElementById("q1o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[0]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==1)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr  class="card shadow-lg">
              <th id="question2" class="card shadow-lg">
                Q.2
                <script>
                  document.getElementById("question2").innerHTML +=
                    mcq_data[1]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered  shadow-lg">
                  <tr>
                    <td id="q2o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q2o1").innerHTML +=
                          mcq_data[1]["opt1"];
                        document
                          .getElementById("q2o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[1]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q2o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q2o2").innerHTML +=
                          mcq_data[1]["opt2"];
                        document
                          .getElementById("q2o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[1]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q2o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q2o3").innerHTML +=
                          mcq_data[1]["opt3"];
                        document
                          .getElementById("q2o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[1]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q2o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q2o4").innerHTML +=
                          mcq_data[1]["opt4"];
                        document
                          .getElementById("q2o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[1]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==2)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question3">
                Q.3
                <script>
                  document.getElementById("question3").innerHTML +=
                    mcq_data[2]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q3o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q3o1").innerHTML +=
                          mcq_data[2]["opt1"];
                        document
                          .getElementById("q3o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[2]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q3o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q3o2").innerHTML +=
                          mcq_data[2]["opt2"];
                        document
                          .getElementById("q3o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[2]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q3o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q3o3").innerHTML +=
                          mcq_data[2]["opt3"];
                        document
                          .getElementById("q3o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[2]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q3o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q3o4").innerHTML +=
                          mcq_data[2]["opt4"];
                        document
                          .getElementById("q3o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[2]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==3)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question4">
                Q.4
                <script>
                  document.getElementById("question4").innerHTML +=
                    mcq_data[3]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q4o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q4o1").innerHTML +=
                          mcq_data[3]["opt1"];
                        document
                          .getElementById("q4o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[3]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q4o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q4o2").innerHTML +=
                          mcq_data[3]["opt2"];
                        document
                          .getElementById("q4o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[3]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q4o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q4o3").innerHTML +=
                          mcq_data[3]["opt3"];
                        document
                          .getElementById("q4o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[3]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q4o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q4o4").innerHTML +=
                          mcq_data[3]["opt4"];
                        document
                          .getElementById("q4o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[3]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==4)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question5">
                Q.5
                <script>
                  document.getElementById("question5").innerHTML +=
                    mcq_data[4]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q5o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q5o1").innerHTML +=
                          mcq_data[4]["opt1"];
                        document
                          .getElementById("q5o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[4]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q5o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q5o2").innerHTML +=
                          mcq_data[4]["opt2"];
                        document
                          .getElementById("q5o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[4]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q5o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q5o3").innerHTML +=
                          mcq_data[4]["opt3"];
                        document
                          .getElementById("q5o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[4]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q5o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q5o4").innerHTML +=
                          mcq_data[4]["opt4"];
                        document
                          .getElementById("q5o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[4]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==5)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->

            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question6">
                Q.6
                <script>
                  document.getElementById("question6").innerHTML +=
                    mcq_data[5]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q6o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q6o1").innerHTML +=
                          mcq_data[5]["opt1"];
                        document
                          .getElementById("q6o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[5]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q6o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q6o2").innerHTML +=
                          mcq_data[5]["opt2"];
                        document
                          .getElementById("q6o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[5]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q6o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q6o3").innerHTML +=
                          mcq_data[5]["opt3"];
                        document
                          .getElementById("q6o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[5]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q6o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q6o4").innerHTML +=
                          mcq_data[5]["opt4"];
                        document
                          .getElementById("q6o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[5]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==6)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question7">
                Q.7
                <script>
                  document.getElementById("question7").innerHTML +=
                    mcq_data[6]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q7o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q7o1").innerHTML +=
                          mcq_data[6]["opt1"];
                        document
                          .getElementById("q7o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[6]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q7o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q7o2").innerHTML +=
                          mcq_data[6]["opt2"];
                        document
                          .getElementById("q7o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[6]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q7o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q7o3").innerHTML +=
                          mcq_data[6]["opt3"];
                        document
                          .getElementById("q7o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[6]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q7o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q7o4").innerHTML +=
                          mcq_data[6]["opt4"];
                        document
                          .getElementById("q7o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[6]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==7)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question8">
                Q.8
                <script>
                  document.getElementById("question8").innerHTML +=
                    mcq_data[7]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q8o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q8o1").innerHTML +=
                          mcq_data[7]["opt1"];
                        document
                          .getElementById("q8o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[7]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q8o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q8o2").innerHTML +=
                          mcq_data[7]["opt2"];
                        document
                          .getElementById("q8o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[7]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q8o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q8o3").innerHTML +=
                          mcq_data[7]["opt3"];
                        document
                          .getElementById("q8o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[7]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q8o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q8o4").innerHTML +=
                          mcq_data[7]["opt4"];
                        document
                          .getElementById("q8o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[7]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==8)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question9">
                Q.9
                <script>
                  document.getElementById("question9").innerHTML +=
                    mcq_data[8]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q9o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q9o1").innerHTML +=
                          mcq_data[8]["opt1"];
                        document
                          .getElementById("q9o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[8]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q9o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q9o2").innerHTML +=
                          mcq_data[8]["opt2"];
                        document
                          .getElementById("q9o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[8]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q9o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q9o3").innerHTML +=
                          mcq_data[8]["opt3"];
                        document
                          .getElementById("q9o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[8]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q9o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q9o4").innerHTML +=
                          mcq_data[8]["opt4"];
                        document
                          .getElementById("q9o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[8]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==9)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
            <!-- Question starts -->
            <tr class="card shadow-lg">
              <th id="question10">
                Q.10
                <script>
                  document.getElementById("question10").innerHTML +=
                    mcq_data[9]["question"];
                </script>
              </th>
            </tr>
            <tr class="card shadow-lg">
              <td>
                <table class="answer table table-bordered shadow-lg">
                  <tr>
                    <td id="q10o1" class="card shadow-lg">
                      &emsp; (A)
                      <script>
                        document.getElementById("q10o1").innerHTML +=
                          mcq_data[9]["opt1"];
                        document
                          .getElementById("q10o1")
                          .setAttribute(
                            "value",
                            "opt1" == mcq_data[9]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q10o2" class="card shadow-lg">
                      &emsp; (B)
                      <script>
                        document.getElementById("q10o2").innerHTML +=
                          mcq_data[9]["opt2"];
                        document
                          .getElementById("q10o2")
                          .setAttribute(
                            "value",
                            "opt2" == mcq_data[9]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q10o3" class="card shadow-lg">
                      &emsp; (C)
                      <script>
                        document.getElementById("q10o3").innerHTML +=
                          mcq_data[9]["opt3"];
                        document
                          .getElementById("q10o3")
                          .setAttribute(
                            "value",
                            "opt3" == mcq_data[9]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                  <tr>
                    <td id="q10o4" class="card shadow-lg">
                      &emsp; (D)
                      <script>
                        document.getElementById("q10o4").innerHTML +=
                          mcq_data[9]["opt4"];
                        document
                          .getElementById("q10o4")
                          .setAttribute(
                            "value",
                            "opt4" == mcq_data[9]["correct_opt"]
                              ? "correct"
                              : "wrong"
                          );
                      </script>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
            <!-- Question ends -->
            <!-- ads_midquestion starts  -->
            <tr>
                <td>
                  <script>
                    if(which_ad==10)ads_midquestion();
                  </script>
                </td>
              </tr>
              <!-- ads_midquestion starts  -->
          </table>
          <!-- pagination starts -->
          <script>
            pages();
          </script>
          <!-- pagination ends -->
        </div>
        <div
          class="col-sm-12 col-md-3 col-lg-3 col-xl-3 section-3 d-none d-sm-block"
        >
          <script>
            ads();
          </script>
        </div>
      </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>
    <script src="https://ml-tweety.github.io/script.js?t464.654"></script>
  </body>
</html>
'''
	if(os.path.exists('categories/')==False):
		os.mkdir('categories/')
	if(os.path.exists('categories/subjects/')==False):
		os.mkdir('categories/subjects/')
	if(os.path.exists('categories/subjects/'+foldername)==False):
		os.mkdir('categories/subjects/'+foldername)


	file = open('categories/subjects/'+foldername+"/"+foldername+"_"+"{:02}".format(page_no)+'.html','w')
	file.write(base_html)
	file.close()

if __name__ == "__main__":
	main()
